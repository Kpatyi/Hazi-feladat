﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Mysqlx.Notice;
using System.Diagnostics;

namespace Órai_feladat8
{
    public partial class Form1 : Form
    {
        private string kapocsolat_adatok = "Server=localhost;Database=filmek;Uid=root;Pwd=;";
        public List<Filmek> filmek = new List<Filmek>();
        public Form1()
        {
            using (var kapcsolat = new MySqlConnection(kapocsolat_adatok))
            {
                kapcsolat.Open();
                string lekerdezes = "SELECT * FROM filmek";
                using (var utasitas = new MySqlCommand(lekerdezes, kapcsolat))
                using (var olvasas = utasitas.ExecuteReader())
                {
                    while (olvasas.Read())
                    {
                        Filmek film = new Filmek(olvasas["cim"].ToString(), olvasas["foszereplo"].ToString(), olvasas["rendezo"].ToString(), int.Parse(olvasas["ev"].ToString()), double.Parse(olvasas["ertekeles"].ToString()), int.Parse(olvasas["nepszeruseg"].ToString()), int.Parse(olvasas["jelolesek"].ToString()), int.Parse(olvasas["dijak"].ToString()), int.Parse(olvasas["oscarok"].ToString()), olvasas["műfaj"].ToString(), double.Parse(olvasas["bevetel"].ToString()), double.Parse(olvasas["koltseg"].ToString()));
                        filmek.Add(film);
                    }
                }
            }
            string kedvenc_film_cim = "Pókember";
            string folytatas_cim = "Pókember 2";
            Filmek kedvenc_film = filmek.Find(i => i.Cim == kedvenc_film_cim);
            Filmek folytatas = filmek.Find(i => i.Cim == folytatas_cim);
            Filmek legtobbre_ertekelet_film = filmek.OrderByDescending(i => i.Ertekeles).First();
            Filmek legnepszerubb_film = filmek.OrderByDescending(i => i.Nepszeruseg).First(); ;
            InitializeComponent();
            filmek.ForEach(i =>
            {
                adatok.Rows.Add(i.Cim, i.Foszereplo, i.Rendezo, i.Ev, i.Ertekeles, i.Nepszeruseg, i.Jelolesek, i.Dijak, i.Oscarok, i.Mufaj, i.Bevetel, i.Koltseg, i.Profit);
            });
            cim1.Text = kedvenc_film_cim;
            link1.Text = kedvenc_film_cim;
            cim2.Text = folytatas_cim;
            link2.Text = folytatas_cim;
            if (kedvenc_film.Profit > folytatas.Profit)
            {
                kimutatasok.Text += $"A(z) {folytatas_cim} több profitott termelt mint a(z) {kedvenc_film_cim}.\r\n";
            }
            else
            {
                kimutatasok.Text += $"A(z) {folytatas_cim} kevesebb profitott termelt mint a(z) {kedvenc_film_cim}.\r\n";
            }

            if (legtobbre_ertekelet_film.Cim == kedvenc_film_cim)
            {
                kimutatasok.Text += $"A(z) {kedvenc_film_cim} a legtöbbre értékelt film az adatok közül.\r\n";
            }
            else
            {
                kimutatasok.Text += $"A(z) {kedvenc_film_cim} nem a legtöbbre értékelt film az adatok közül mert a(z) {legtobbre_ertekelet_film.Cim} az.\r\n";
            }

            if (Tobb_profit_ertekeles(kedvenc_film_cim))
            {
                kimutatasok.Text += $"A(z) {kedvenc_film_cim} több profitot termelt mint a legtöbbre értékelt film.\r\n";
            }
            else
            {
                kimutatasok.Text += $"A(z) {kedvenc_film_cim} kevesebb profitot termelt mint a legtöbbre értékelt film.\r\n";
            }

            if (legnepszerubb_film.Cim == kedvenc_film_cim)
            {
                kimutatasok.Text += $"A(z) {kedvenc_film_cim} a legnépszerűbb film.\r\n";
            }
            else
            {
                kimutatasok.Text += $"A(z) {kedvenc_film_cim} nem a legnépszerűbb film mert a(z) {legnepszerubb_film.Cim} az.\r\n";
            }
            kimutatasok.Text += $"A(z) {kedvenc_film_cim} az átlag népszerűségtől {Nepszerusseg_atlag_elteres_szazalak(kedvenc_film)}%-al tér el.\r\n";
            kimutatasok.Text += $"A(z) {kedvenc_film_cim} a jelöléseinek a {Jelolesek_gyozelme_szazalek(kedvenc_film_cim)}%-át megnyerte\r\n";
            kimutatasok.Text += $"A népszerűség terjedelme: {Terjedelem_nepszeruseg()}\r\n";
            kimutatasok.Text += $"A népszerűség szórása: {Szoras_nepszeruseg()}";
        }

        public bool Tobb_profit_ertekeles(string film_cim)
        {
            Filmek legtobbre_ertekelt_film = filmek.OrderByDescending(i => i.Ertekeles).First();
            Filmek film = filmek.Find(i => i.Cim == film_cim);
            if (film.Profit > legtobbre_ertekelt_film.Profit)
            {
                return true;
            }
            return false;
        }
        public double Nepszerusseg_atlag_elteres_szazalak(Filmek film)
        {
            double atlag = filmek.Average(i=>i.Nepszeruseg);
            double elteres = Math.Abs(atlag-film.Nepszeruseg);
            return Math.Round(elteres /atlag*100,2);
        }

        public double Jelolesek_gyozelme_szazalek(string film_cim)
        {
            Filmek film = filmek.Find(i => i.Cim == film_cim);
            double dijak = film.Dijak;
            double jelolesek = film.Jelolesek;
            double szazalek =Math.Round(dijak / jelolesek * 100,2);
            return szazalek;
        }

        public double Terjedelem_nepszeruseg()
        {
            double legnagyobb = filmek.Max(i => i.Nepszeruseg);
            double legkisebb = filmek.Min(i => i.Nepszeruseg);
            double terjedelem = legnagyobb - legkisebb;
            return terjedelem;
        }

        public double Szoras_nepszeruseg()
        {
            double atlag = filmek.Average(i => i.Nepszeruseg);
            double osszeg = 0;
            filmek.ForEach(i =>
            {
                osszeg += Math.Pow(i.Nepszeruseg - atlag,2); 
            });
            double szoras = Math.Round(Math.Sqrt(osszeg / filmek.Count),2);
            return szoras;
        }

        private void link1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://www.youtube.com/watch?v=t06RUxPbp_c&ab_channel=SonyPicturesEntertainment");
        }

        private void link2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://www.youtube.com/watch?v=3jBFwltrxJw&ab_channel=SonyPicsatHome");
        }
    }
}
