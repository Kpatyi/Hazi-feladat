﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Órai_feladat8
{
    public class Filmek
    {
        public string Cim { get; set; }
        public string Foszereplo { get; set; }
        public string Rendezo { get; set; }
        public int Ev { get; set; }
        public double Ertekeles { get; set; }
        public int Nepszeruseg {  get; set; }
        public int Jelolesek { get; set; }
        public int Dijak {  get; set; }
        public int Oscarok {  get; set; }
        public string Mufaj { get; set; }
        public double Bevetel {  get; set; }
        public double Koltseg { get; set; }
        public double Profit { get; set; }
        public Filmek(string cim,string foszereplo, string rendezo, int ev, double ertekeles, int nepszeruseg, int jelolesek, int dijak, int oscarok, string mufaj, double bevetel, double koltseg)
        {
            Cim = cim;
            Foszereplo = foszereplo;
            Rendezo = rendezo;
            Ev = ev;
            Ertekeles = ertekeles;
            Nepszeruseg = nepszeruseg;
            Jelolesek = jelolesek;
            Dijak = dijak;
            Oscarok = oscarok;
            Mufaj = mufaj;
            Bevetel = bevetel;
            Koltseg = koltseg;
            Profit = bevetel - koltseg;
        }
    }
}
