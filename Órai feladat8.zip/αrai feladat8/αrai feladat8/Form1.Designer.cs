﻿namespace Órai_feladat8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.adatok = new System.Windows.Forms.DataGridView();
            this.cim = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foszereplo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rendezo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ev = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ertekeles = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nepszeruseg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jelolesek = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dijak = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oscarok = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mufaj = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bevetel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.koltseg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.profit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.kimutatasok = new System.Windows.Forms.TextBox();
            this.legnepszerubb_ki = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.cim2 = new System.Windows.Forms.Label();
            this.link2 = new System.Windows.Forms.LinkLabel();
            this.link1 = new System.Windows.Forms.LinkLabel();
            this.cim1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.adatok)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // adatok
            // 
            this.adatok.BackgroundColor = System.Drawing.Color.White;
            this.adatok.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adatok.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cim,
            this.foszereplo,
            this.rendezo,
            this.ev,
            this.ertekeles,
            this.nepszeruseg,
            this.jelolesek,
            this.dijak,
            this.oscarok,
            this.mufaj,
            this.bevetel,
            this.koltseg,
            this.profit});
            this.adatok.Location = new System.Drawing.Point(7, 6);
            this.adatok.Name = "adatok";
            this.adatok.Size = new System.Drawing.Size(1343, 352);
            this.adatok.TabIndex = 0;
            // 
            // cim
            // 
            this.cim.HeaderText = "Cím";
            this.cim.Name = "cim";
            this.cim.ReadOnly = true;
            // 
            // foszereplo
            // 
            this.foszereplo.HeaderText = "Főszereplő";
            this.foszereplo.Name = "foszereplo";
            this.foszereplo.ReadOnly = true;
            // 
            // rendezo
            // 
            this.rendezo.HeaderText = "Rendező";
            this.rendezo.Name = "rendezo";
            this.rendezo.ReadOnly = true;
            // 
            // ev
            // 
            this.ev.HeaderText = "Év";
            this.ev.Name = "ev";
            this.ev.ReadOnly = true;
            // 
            // ertekeles
            // 
            this.ertekeles.HeaderText = "Értékelés";
            this.ertekeles.Name = "ertekeles";
            this.ertekeles.ReadOnly = true;
            // 
            // nepszeruseg
            // 
            this.nepszeruseg.HeaderText = "Népszerűség";
            this.nepszeruseg.Name = "nepszeruseg";
            this.nepszeruseg.ReadOnly = true;
            // 
            // jelolesek
            // 
            this.jelolesek.HeaderText = "Jelölések";
            this.jelolesek.Name = "jelolesek";
            this.jelolesek.ReadOnly = true;
            // 
            // dijak
            // 
            this.dijak.HeaderText = "Díjak";
            this.dijak.Name = "dijak";
            this.dijak.ReadOnly = true;
            // 
            // oscarok
            // 
            this.oscarok.HeaderText = "Oscarok";
            this.oscarok.Name = "oscarok";
            this.oscarok.ReadOnly = true;
            // 
            // mufaj
            // 
            this.mufaj.HeaderText = "Műfaj";
            this.mufaj.Name = "mufaj";
            this.mufaj.ReadOnly = true;
            // 
            // bevetel
            // 
            this.bevetel.HeaderText = "Bevétel";
            this.bevetel.Name = "bevetel";
            this.bevetel.ReadOnly = true;
            // 
            // koltseg
            // 
            this.koltseg.HeaderText = "Költség";
            this.koltseg.Name = "koltseg";
            this.koltseg.ReadOnly = true;
            // 
            // profit
            // 
            this.profit.HeaderText = "Profit";
            this.profit.Name = "profit";
            this.profit.ReadOnly = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(4, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1600, 1000);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.adatok);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1547, 974);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Adatok";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.kimutatasok);
            this.tabPage2.Controls.Add(this.legnepszerubb_ki);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1547, 524);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Kiértékelések";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // kimutatasok
            // 
            this.kimutatasok.BackColor = System.Drawing.Color.White;
            this.kimutatasok.Font = new System.Drawing.Font("Times New Roman", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kimutatasok.Location = new System.Drawing.Point(64, 5);
            this.kimutatasok.Multiline = true;
            this.kimutatasok.Name = "kimutatasok";
            this.kimutatasok.ReadOnly = true;
            this.kimutatasok.Size = new System.Drawing.Size(1212, 470);
            this.kimutatasok.TabIndex = 11;
            // 
            // legnepszerubb_ki
            // 
            this.legnepszerubb_ki.AutoSize = true;
            this.legnepszerubb_ki.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.legnepszerubb_ki.Location = new System.Drawing.Point(2, 13);
            this.legnepszerubb_ki.Name = "legnepszerubb_ki";
            this.legnepszerubb_ki.Size = new System.Drawing.Size(0, 22);
            this.legnepszerubb_ki.TabIndex = 7;
            // 
            // tabPage3
            // 
            this.tabPage3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage3.BackgroundImage")));
            this.tabPage3.Controls.Add(this.cim2);
            this.tabPage3.Controls.Add(this.link2);
            this.tabPage3.Controls.Add(this.link1);
            this.tabPage3.Controls.Add(this.cim1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1592, 974);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Videók";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // cim2
            // 
            this.cim2.AutoSize = true;
            this.cim2.Font = new System.Drawing.Font("Times New Roman", 50.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cim2.ForeColor = System.Drawing.Color.White;
            this.cim2.Location = new System.Drawing.Point(688, 16);
            this.cim2.Name = "cim2";
            this.cim2.Size = new System.Drawing.Size(167, 76);
            this.cim2.TabIndex = 4;
            this.cim2.Text = "cim2";
            // 
            // link2
            // 
            this.link2.AutoSize = true;
            this.link2.Font = new System.Drawing.Font("Times New Roman", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.link2.ForeColor = System.Drawing.Color.White;
            this.link2.Location = new System.Drawing.Point(758, 128);
            this.link2.Name = "link2";
            this.link2.Size = new System.Drawing.Size(159, 37);
            this.link2.TabIndex = 3;
            this.link2.TabStop = true;
            this.link2.Text = "linkLabel1";
            this.link2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link2_LinkClicked);
            // 
            // link1
            // 
            this.link1.AutoSize = true;
            this.link1.Font = new System.Drawing.Font("Times New Roman", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.link1.ForeColor = System.Drawing.Color.White;
            this.link1.Location = new System.Drawing.Point(223, 140);
            this.link1.Name = "link1";
            this.link1.Size = new System.Drawing.Size(159, 37);
            this.link1.TabIndex = 2;
            this.link1.TabStop = true;
            this.link1.Text = "linkLabel1";
            this.link1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link1_LinkClicked);
            // 
            // cim1
            // 
            this.cim1.AutoSize = true;
            this.cim1.Font = new System.Drawing.Font("Times New Roman", 50.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cim1.ForeColor = System.Drawing.Color.White;
            this.cim1.Location = new System.Drawing.Point(164, 16);
            this.cim1.Name = "cim1";
            this.cim1.Size = new System.Drawing.Size(167, 76);
            this.cim1.TabIndex = 0;
            this.cim1.Text = "cim1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1584, 961);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.adatok)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView adatok;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label legnepszerubb_ki;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label cim1;
        private System.Windows.Forms.LinkLabel link1;
        private System.Windows.Forms.Label cim2;
        private System.Windows.Forms.LinkLabel link2;
        private System.Windows.Forms.DataGridViewTextBoxColumn cim;
        private System.Windows.Forms.DataGridViewTextBoxColumn foszereplo;
        private System.Windows.Forms.DataGridViewTextBoxColumn rendezo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ev;
        private System.Windows.Forms.DataGridViewTextBoxColumn ertekeles;
        private System.Windows.Forms.DataGridViewTextBoxColumn nepszeruseg;
        private System.Windows.Forms.DataGridViewTextBoxColumn jelolesek;
        private System.Windows.Forms.DataGridViewTextBoxColumn dijak;
        private System.Windows.Forms.DataGridViewTextBoxColumn oscarok;
        private System.Windows.Forms.DataGridViewTextBoxColumn mufaj;
        private System.Windows.Forms.DataGridViewTextBoxColumn bevetel;
        private System.Windows.Forms.DataGridViewTextBoxColumn koltseg;
        private System.Windows.Forms.TextBox kimutatasok;
        private System.Windows.Forms.DataGridViewTextBoxColumn profit;
    }
}

