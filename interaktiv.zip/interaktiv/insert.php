<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Insert data</title>
</head>

<body>
    <?php
    include "kapcsolat.php";


    $tabla = "CREATE TABLE IF NOT EXISTS users(

    id int PRIMARY KEY AUTO_INCREMENT,
    nev varchar(100)  NOT NULL,
    email varchar(100)  NOT NULL,
    password varchar(100)  NOT NULL



);";

    $stmt_prepare = mysqli_prepare($conn, $tabla);
    mysqli_stmt_execute($stmt_prepare);

    if (check_fields()) {
        user_create();
    }

    function check_fields()
    {
        $nev = isset($_POST["nev"]) && !empty($_POST["nev"]);
        $email = isset($_POST["email"]) && !empty($_POST["email"]);
        $password = isset($_POST["password"]) && !empty($_POST["password"]);
        return $nev &&  $email && $password;
    }

    function user_create()
    {
        global $conn;
        $nev = $_REQUEST["nev"];
        $email = $_REQUEST["email"];
        $password = $_REQUEST["password"];

        $stmt = "INSERT INTO users (nev,email,password) VALUES ('$nev', '$email', '$password')";
        $stmt_prepare2 = mysqli_prepare($conn, $stmt);
        mysqli_stmt_execute($stmt_prepare2);
    }


    ?>

    <h1>A módosítás megtörtént</h1>

    <a href="index.php"><button class="btn btn-success">Vissza a főoldalra</button></a>




</body>

</html>