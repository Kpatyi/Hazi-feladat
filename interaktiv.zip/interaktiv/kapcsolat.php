<?php

$databaseHost = '127.0.0.1';
$databaseUsername = 'root';
$databasePassword = '';
$databaseName = 'adatbazis';


$conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);



mysqli_set_charset($conn, 'utf8');
