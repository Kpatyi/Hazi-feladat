let irany="ArrowRight";
let utkozott=false;
let indulas;
let pont=0;
let kigyo;
let uj_irany;
function Inditas(event)
{
    if(!utkozott)
    {
        uj_irany=event.key;
        clearInterval(indulas);
        indulas=setInterval(Mozgas,215);
    }
}

function Mozgas()
{
    if(irany!=uj_irany)
    {
        if((irany=="ArrowLeft" && uj_irany!="ArrowRight") || (irany=="ArrowRight" && uj_irany!="ArrowLeft") || (irany=="ArrowUp" && uj_irany!="ArrowDown") || (irany=="ArrowDown" && uj_irany!="ArrowUp"))
        {
            irany=uj_irany;
        }
    }

    let kigyo=document.getElementById("kigyo");
    let kigyo_hely={x:parseInt(kigyo.getAttribute("x")),y:parseInt(kigyo.getAttribute("y"))};
    let lepes=50;
    Nezes(kigyo);
    if(!Utkozes(kigyo_hely,lepes))
    {
        Test_mozgas(kigyo_hely,lepes);
        switch(irany)
        {
            case "ArrowLeft":
                kigyo_hely.x-=lepes;
                break;
            case "ArrowRight":
                kigyo_hely.x+=lepes;
                break;
            case "ArrowUp":
                kigyo_hely.y-=lepes;
                break;
            case "ArrowDown":
                kigyo_hely.y+=lepes;
        }
        kigyo.setAttribute("x",kigyo_hely.x);
        kigyo.setAttribute("y",kigyo_hely.y);
        Novekedes(kigyo_hely,lepes);
    }
    else
    {
        alert("Vége");
        clearInterval(indulas);
    }
}

function Utkozes(kigyo_hely,lepes)
{
    const testek=document.getElementsByClassName("test");
    if((kigyo_hely.x+lepes<850 && irany=="ArrowRight") || (kigyo_hely.x-lepes>-50 && irany=="ArrowLeft") ||(kigyo_hely.y+lepes<750 && irany=="ArrowDown") || (kigyo_hely.y-lepes>-50 && irany=="ArrowUp"))
    {
        for(let i=testek.length-1;i>=0;i--)
        {
            let x=parseInt(testek[i].getAttribute("x"));
            let y=parseInt(testek[i].getAttribute("y"));
            if((kigyo_hely.x+lepes==x && irany=="ArrowRight" && kigyo_hely.y==y) || (kigyo_hely.x-lepes==x && irany=="ArrowLeft" && kigyo_hely.y==y) || (kigyo_hely.y+lepes==y && irany=="ArrowDown" && kigyo_hely.x==x) || (kigyo_hely.y-lepes==y && irany=="ArrowUp" && kigyo_hely.x==x))
            {
                return true; 
            }
        }
        return false;
    }
    else
    {
        return true;
    }
}

function Nezes(kigyo)
{
    switch(irany)
    {
        case "ArrowLeft":
            kigyo.setAttribute("href","Képek/leftmouth.gif");
            break;
        case "ArrowRight":
            kigyo.setAttribute("href","Képek/rightmouth.gif");
            break;
        case "ArrowUp":
            kigyo.setAttribute("href","Képek/upmouth.gif");
            break;
        case "ArrowDown":
            kigyo.setAttribute("href","Képek/downmouth.gif");
    }
}

function Novekedes(kigyo_hely,lepes)
{
    let kaja=document.getElementById("kaja");
    let kaja_hely={x:parseInt(kaja.getAttribute("x")),y:parseInt(kaja.getAttribute("y"))};
    let palya=document.getElementById("palya");
    const testek=document.getElementsByClassName("test");
    if(kigyo_hely.x==kaja_hely.x-10 && kigyo_hely.y==kaja_hely.y)
    {
        const pontok=[];
        for(let i=0;i<testek.length;i++)
        {
            test_hely={x:(parseInt(testek[i].getAttribute("x"))-10),y:parseInt(testek[i].getAttribute("y"))};
            pontok.push(test_hely);
        }
        let uj_pont={x:(Math.round(Math.random()*810)),y:(Math.round(Math.random()*700))}
        while(((kigyo_hely.x-10)==uj_pont.x && kigyo_hely.y==uj_pont.y) || (uj_pont.x-10)%50!=0 || uj_pont.y%50!=0)
        {
            uj_pont.x=Math.round(Math.random()*810);
            uj_pont.y=Math.round(Math.random()*700);
        }
        kaja.setAttribute("x",uj_pont.x);
        kaja.setAttribute("y",uj_pont.y);
        pont++;
        document.getElementById("pont").innerHTML=pont;
        if(testek.length==0)
        {
            switch(irany)
            {
                case "ArrowLeft":
                    kigyo_hely.x+=lepes;
                    break;
                case "ArrowRight":
                    kigyo_hely.x-=lepes;
                    break;
                case "ArrowUp":
                    kigyo_hely.y+=lepes;
                    break;
                case "ArrowDown":
                    kigyo_hely.y-=lepes;
            }
            palya.innerHTML+="<image href='Képek/test.gif' class='test' x='"+kigyo_hely.x+"' y='"+kigyo_hely.y+"'></image>";
        }
        else
        {
            palya.innerHTML+="<image href='Képek/test.gif' class='test' x='"+testek[testek.length-1].getAttribute("x")+"' y='"+testek[testek.length-1].getAttribute("y")+"'></image>";
        }
    }
}

function Test_mozgas(kigyo_hely,lepes)
{
    const testek=document.getElementsByClassName("test");
    for(let i=testek.length-1;i>=0;i--)
    {
        let x=parseInt(testek[i].getAttribute("x")); 
        let y=parseInt(testek[i].getAttribute("y"));
        if(i==0)
        {
            if(x>kigyo_hely.x)
            {
                x-=lepes;
            }

            if(x<kigyo_hely.x)
            {
                x+=lepes;
            }
    
            if(y>kigyo_hely.y)
            {
                y-=lepes;
            }
        
            if(y<kigyo_hely.y)
            {
                y+=lepes;
            }
        }
        else
        {
            if(x>parseInt(testek[i-1].getAttribute("x")))
            {
                x-=lepes;
            }

            if(x<parseInt(testek[i-1].getAttribute("x")))
            {
                x+=lepes;
            }

            if(y>parseInt(testek[i-1].getAttribute("y")))
            {
                y-=lepes;
            }
    
            if(y<parseInt(testek[i-1].getAttribute("y")))
            {
                y+=lepes;
            }
        }
        testek[i].setAttribute("x",x);
        testek[i].setAttribute("y",y);
    }
}