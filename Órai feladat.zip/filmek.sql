-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Már 13. 22:17
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `filmek`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `filmek`
--

CREATE TABLE `filmek` (
  `id` int(11) NOT NULL,
  `cim` varchar(255) NOT NULL,
  `foszereplo` varchar(255) NOT NULL,
  `rendezo` varchar(255) NOT NULL,
  `ev` int(11) NOT NULL,
  `ertekeles` double(2,1) NOT NULL,
  `nepszeruseg` int(11) NOT NULL,
  `jelolesek` int(11) NOT NULL,
  `dijak` int(11) NOT NULL,
  `oscarok` int(11) NOT NULL,
  `műfaj` varchar(255) NOT NULL,
  `bevetel` double(4,1) NOT NULL,
  `koltseg` double(4,1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `filmek`
--

INSERT INTO `filmek` (`id`, `cim`, `foszereplo`, `rendezo`, `ev`, `ertekeles`, `nepszeruseg`, `jelolesek`, `dijak`, `oscarok`, `műfaj`, `bevetel`, `koltseg`) VALUES
(1, 'Pókember', 'Tobey Maguire', 'Sam Raimi', 2002, 7.4, 307, 65, 17, 0, 'akció', 821.7, 139.0),
(2, 'Pókember 2', 'Tobey Maguire', 'Sam Raimi', 2004, 7.5, 740, 60, 25, 1, 'akció', 789.0, 200.0);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `filmek`
--
ALTER TABLE `filmek`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `filmek`
--
ALTER TABLE `filmek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
